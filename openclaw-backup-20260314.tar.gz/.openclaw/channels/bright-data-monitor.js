/**
 * OpenClaw Channel: Bright Data Product Monitor
 * 
 * 功能：使用Bright Data API监控Amazon产品数据
 * 调度：每小时
 * 超时：10分钟
 * 
 * 数据流：
 * 1. 通过关键词/类别发现产品
 * 2. 抓取产品详情
 * 3. 批量写入FastAPI
 */

const http = require('http');
const https = require('https');

// 配置
const FASTAPI_BASE_URL = 'http://172.22.0.4:8000';
const BRIGHTDATA_API_KEY = '1c7806b0-3f98-48da-93ce-8a745c40b062';
const BRIGHTDATA_DATASET_ID = 'gd_l7q7dkf244hwjntr0';

// 产品类别
const PRODUCT_CATEGORIES = [
    { keyword: 'wireless earbuds', category: 'wireless_earbuds' },
    { keyword: 'bluetooth speakers', category: 'bluetooth_speakers' },
    { keyword: 'smart plug', category: 'smart_plugs' },
    { keyword: 'desk lamp', category: 'desk_lamps' },
    { keyword: 'phone charger', category: 'phone_chargers' },
    { keyword: 'fitness tracker', category: 'fitness_trackers' },
    { keyword: 'coffee maker', category: 'coffee_makers' },
    { keyword: 'air purifier', category: 'air_purifiers' }
];

/**
 * 发起HTTP请求
 */
function httpRequest(url, options = {}) {
    return new Promise((resolve, reject) => {
        const client = url.startsWith('https') ? https : http;
        const req = client.request(url, options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    resolve(JSON.parse(data));
                } catch (e) {
                    resolve(data);
                }
            });
        });
        
        req.on('error', reject);
        req.setTimeout(180000, () => {
            req.destroy();
            reject(new Error('Request timeout'));
        });
        
        if (options.body) {
            req.write(JSON.stringify(options.body));
        }
        req.end();
    });
}

/**
 * 通过关键词发现产品
 */
async function discoverByKeywords(keywords) {
    const url = 'https://api.brightdata.com/datasets/v3/scrape';
    
    const input = keywords.map(kw => ({
        keyword: kw.keyword,
        zipcode: '94107'
    }));

    try {
        const response = await httpRequest(url, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${BRIGHTDATA_API_KEY}`,
                'Content-Type': 'application/json'
            },
            search: `?dataset_id=${BRIGHTDATA_DATASET_ID}&notify=false&include_errors=true&type=discover_new&discover_by=keyword`,
            body: { input }
        });

        const snapshotId = response.snapshot_id;
        console.log(`[BrightData] Snapshot created: ${snapshotId}`);
        return snapshotId;
    } catch (error) {
        console.error('Failed to discover products:', error.message);
        return null;
    }
}

/**
 * 监控snapshot进度
 */
async function monitorSnapshot(snapshotId, maxWait = 180) {
    const url = `https://api.brightdata.com/datasets/v3/snapshots/${snapshotId}`;
    const startTime = Date.now();

    while (true) {
        const elapsed = (Date.now() - startTime) / 1000;
        if (elapsed > maxWait) {
            console.log(`[BrightData] Snapshot timeout after ${maxWait}s`);
            return false;
        }

        try {
            const status = await httpRequest(url, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${BRIGHTDATA_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            });

            if (status.status === 'ready') {
                console.log(`[BrightData] Snapshot ready: ${snapshotId}`);
                return true;
            } else if (status.status === 'failed') {
                console.error(`[BrightData] Snapshot failed: ${snapshotId}`);
                return false;
            }

            console.log(`[BrightData] Snapshot status: ${status.status}`);
            await new Promise(resolve => setTimeout(resolve, 5000));
        } catch (error) {
            console.error('Failed to check snapshot status:', error.message);
            await new Promise(resolve => setTimeout(resolve, 5000));
        }
    }
}

/**
 * 下载snapshot数据
 */
async function downloadSnapshot(snapshotId) {
    const url = `https://api.brightdata.com/datasets/v3/snapshots/${snapshotId}`;

    try {
        const response = await httpRequest(url, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${BRIGHTDATA_API_KEY}`,
                'Content-Type': 'application/json'
            }
        });

        // 返回原始数据（JSONL格式）
        return response;
    } catch (error) {
        console.error('Failed to download snapshot:', error.message);
        return [];
    }
}

/**
 * 批量写入产品到FastAPI
 */
async function pushProductsToFastAPI(productsData) {
    const url = `${FASTAPI_BASE_URL}/api/v1/batch/products`;
    const payload = {
        products: productsData,
        source: 'brightdata',
        batch_id: `bd-${Date.now()}`
    };

    try {
        const response = await httpRequest(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: payload
        });
        return response;
    } catch (error) {
        console.error('Failed to push products:', error.message);
        throw error;
    }
}

/**
 * 使用ASIN直接抓取产品详情 (同步方式)
 */
async function scrapeProductsByAsins(asins) {
    const url = 'https://api.brightdata.com/datasets/v3/scrape';

    const input = asins.map(asin => ({
        url: `https://www.amazon.com/dp/${asin}`,
        zipcode: '94107'
    }));

    try {
        const response = await httpRequest(url, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${BRIGHTDATA_API_KEY}`,
                'Content-Type': 'application/json'
            },
            search: `?dataset_id=${BRIGHTDATA_DATASET_ID}&notify=false&include_errors=true`,
            body: { input }
        });

        // 解析JSONL响应
        const results = [];
        const lines = response.split('\n').filter(line => line.trim());
        
        for (const line of lines) {
            try {
                const data = JSON.parse(line);
                if (!data.error) {
                    results.push({
                        asin: data.asin,
                        title: data.title,
                        brand: data.brand || data.manufacturer,
                        price: data.final_price,
                        original_price: data.initial_price,
                        currency: data.currency || 'USD',
                        rating: data.rating,
                        reviews_count: data.reviews_count,
                        image_url: data.image_url || data.image,
                        url: data.url,
                        data_source: 'brightdata'
                    });
                }
            } catch (e) {
                // Skip invalid JSON
            }
        }

        return results;
    } catch (error) {
        console.error('Failed to scrape products:', error.message);
        return [];
    }
}

/**
 * 主执行函数
 */
async function run(params = {}) {
    console.log('[Bright Data Monitor] Starting execution...');
    const startTime = Date.now();

    try {
        const categories = params.categories || PRODUCT_CATEGORIES;
        const limit = params.limit || 5;

        // 方式1: 直接抓取已知ASIN的产品详情
        // 这里使用示例ASIN列表，实际应该从数据库获取
        const sampleAsins = [
            'B08C5K2N2L', 'B094NC89P9', 'B01M4MCUAF', 
            'B07PZF3QS3', 'B08GB3QC1H', 'B0BRR4ZGNP'
        ];

        console.log(`[Bright Data Monitor] Scraping ${sampleAsins.length} products...`);
        const products = await scrapeProductsByAsins(sampleAsins.slice(0, limit));
        console.log(`[Bright Data Monitor] Got ${products.length} products`);

        if (products.length > 0) {
            // 按类别分组
            const productsByCategory = {};
            products.forEach(p => {
                const category = params.defaultCategory || 'electronics';
                if (!productsByCategory[category]) {
                    productsByCategory[category] = [];
                }
                productsByCategory[category].push(p);
            });

            // 推送到FastAPI
            for (const [category, categoryProducts] of Object.entries(productsByCategory)) {
                console.log(`[Bright Data Monitor] Pushing ${categoryProducts.length} ${category} products...`);
                
                const payload = {
                    products: categoryProducts,
                    category: category,
                    source: 'brightdata',
                    batch_id: `bd-${category}-${Date.now()}`
                };

                await pushProductsToFastAPI(payload);
            }
        }

        const duration = Date.now() - startTime;
        console.log(`[Bright Data Monitor] Completed in ${duration}ms`);

        return {
            success: true,
            channel: 'bright-data-monitor',
            execution_id: params.execution_id || `exec-${Date.now()}`,
            stats: {
                total_queried: sampleAsins.length,
                total_scraped: products.length,
                duration_ms: duration
            },
            message: `Successfully scraped ${products.length} products`
        };

    } catch (error) {
        console.error('[Bright Data Monitor] Error:', error);
        return {
            success: false,
            channel: 'bright-data-monitor',
            error: error.message,
            duration_ms: Date.now() - startTime
        };
    }
}

// 导出
module.exports = {
    id: 'bright-data-monitor',
    name: 'Bright Data Product Monitor',
    version: '1.0.0',
    schedule: '0 * * * *',
    timeout: 600000, // 10分钟
    description: '使用Bright Data API监控Amazon产品数据',
    run: run
};

// 如果直接运行此脚本
if (require.main === module) {
    run({ limit: 5 }).then(result => {
        console.log('Result:', JSON.stringify(result, null, 2));
        process.exit(result.success ? 0 : 1);
    }).catch(error => {
        console.error('Fatal error:', error);
        process.exit(1);
    });
}
