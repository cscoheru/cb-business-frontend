/**
 * OpenClaw Channel: Trend Discovery
 * 
 * 功能：分析最近7天的高机会文章，发现新兴趋势
 * 调度：每6小时
 * 超时：10分钟
 * 
 * 数据流：
 * 1. 查询高opportunity_score文章
 * 2. 分析关键词频率
 * 3. 识别新兴产品类别
 * 4. 生成AI市场洞察
 */

const http = require('http');
const https = require('https');

// 配置
const FASTAPI_BASE_URL = 'http://172.22.0.4:8000';
const GLM_API_URL = 'https://open.bigmodel.cn/api/paas/v4/chat/completions';
const GLM_API_KEY = 'ed79dfb6bd5d442b9818011010d6faed.ExkY3SyIQqoyDpaO';

/**
 * 发起HTTP请求
 */
function httpRequest(url, options = {}) {
    return new Promise((resolve, reject) => {
        const client = url.startsWith('https') ? https : http;
        const req = client.request(url, options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    resolve(JSON.parse(data));
                } catch (e) {
                    resolve(data);
                }
            });
        });
        
        req.on('error', reject);
        req.setTimeout(120000, () => {
            req.destroy();
            reject(new Error('Request timeout'));
        });
        
        if (options.body) {
            req.write(JSON.stringify(options.body));
        }
        req.end();
    });
}

/**
 * 获取高机会文章
 */
async function fetchHighOpportunityArticles(days = 7) {
    const url = `${FASTAPI_BASE_URL}/api/v1/crawler/articles?per_page=100&days=${days}`;
    
    try {
        const response = await httpRequest(url, {
            method: 'GET',
            headers: {
                'Accept': 'application/json'
            }
        });
        
        const articles = response.articles || response.data || [];
        // 筛选高机会文章 (opportunity_score >= 0.7)
        return articles.filter(a => 
            a.opportunity_score >= 0.7 || 
            a.content_theme === 'opportunity'
        );
    } catch (error) {
        console.error('Failed to fetch articles:', error.message);
        return [];
    }
}

/**
 * 分析关键词频率
 */
function analyzeKeywordFrequency(articles) {
    const keywordMap = new Map();
    
    articles.forEach(article => {
        let keywords = [];
        if (Array.isArray(article.keywords)) {
            keywords = article.keywords;
        } else if (typeof article.keywords === 'string') {
            try {
                keywords = JSON.parse(article.keywords);
            } catch (e) {
                keywords = article.keywords.split(',').map(k => k.trim());
            }
        } else if (article.tags) {
            keywords = article.tags;
        }
        
        keywords.forEach(keyword => {
            const normalized = keyword.toLowerCase().trim();
            if (normalized.length > 2) {
                keywordMap.set(normalized, (keywordMap.get(normalized) || 0) + 1);
            }
        });
    });
    
    // 返回前20个高频关键词
    return Array.from(keywordMap.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 20)
        .map(([keyword, count]) => ({ keyword, count }));
}

/**
 * 识别热门类别
 */
function identifyTrendingCategories(articles) {
    const categoryMap = new Map();
    
    articles.forEach(article => {
        const category = article.category || article.content_theme || 'other';
        const score = article.opportunity_score || 0.5;
        
        if (!categoryMap.has(category)) {
            categoryMap.set(category, { count: 0, totalScore: 0 });
        }
        
        const data = categoryMap.get(category);
        data.count++;
        data.totalScore += score;
    });
    
    return Array.from(categoryMap.entries())
        .map(([category, data]) => ({
            category,
            count: data.count,
            avgScore: data.totalScore / data.count
        }))
        .sort((a, b) => b.avgScore - a.avgScore)
        .slice(0, 10);
}

/**
 * 使用GLM-4 Plus生成趋势洞察
 */
async function generateTrendInsights(topKeywords, trendingCategories, recentArticles) {
    const prompt = `你是一位跨境电商市场趋势分析专家。基于以下数据，请生成一份趋势洞察报告。

【热门关键词】(Top 20)
${topKeywords.map((k, i) => `${i + 1}. ${k.keyword} (出现${k.count}次)`).join('\n')}

【热门类别】(按平均机会评分排序)
${trendingCategories.map((c, i) => 
    `${i + 1}. ${c.category} (文章数:${c.count}, 平均评分:${c.avgScore.toFixed(2)})`
).join('\n')}

【最新高机会文章示例】
${recentArticles.slice(0, 5).map((a, i) => 
    `${i + 1}. ${a.title}\n   类别: ${a.content_theme}, 地区: ${a.region}, 评分: ${a.opportunity_score}`
).join('\n\n')}

请生成JSON格式的趋势报告：
{
  "summary": "趋势概述(2-3句话)",
  "emerging_trends": [
    {
      "trend": "趋势名称",
      "description": "趋势描述",
      "opportunity_level": "high|medium|low",
      "related_keywords": ["关键词1", "关键词2"]
    }
  ],
  "top_categories": [
    {
      "category": "类别名称",
      "insight": "类别洞察"
    }
  ],
  "actionable_insights": [
    "可执行洞察1",
    "可执行洞察2"
  ]
}

只返回JSON，不要其他说明。`;

    try {
        const response = await httpRequest(GLM_API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${GLM_API_KEY}`
            },
            body: {
                model: 'glm-4-plus',
                messages: [
                    {
                        role: 'user',
                        content: prompt
                    }
                ],
                temperature: 0.4,
                max_tokens: 3000
            }
        });

        const content = response.choices[0].message.content;
        // 提取JSON对象
        const jsonMatch = content.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
            return JSON.parse(jsonMatch[0]);
        }
        throw new Error('Failed to extract JSON from GLM response');
    } catch (error) {
        console.error('GLM trend analysis error:', error.message);
        return {
            summary: '趋势分析暂时不可用',
            emerging_trends: [],
            top_categories: [],
            actionable_insights: []
        };
    }
}

/**
 * 保存趋势到FastAPI (通过keywords API)
 */
async function saveTrendsToFastAPI(trendData) {
    const url = `${FASTAPI_BASE_URL}/api/v1/trends/keywords`;
    
    try {
        const response = await httpRequest(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: trendData
        });
        return response;
    } catch (error) {
        console.error('Failed to save trends:', error.message);
        // 不抛出错误，继续执行
        return { success: false };
    }
}

/**
 * 主执行函数
 */
async function run(params = {}) {
    console.log('[Trend Discovery] Starting execution...');
    const startTime = Date.now();

    try {
        const days = params.days || 7;
        
        // 1. 获取高机会文章
        console.log(`[Trend Discovery] Fetching high-opportunity articles (last ${days} days)...`);
        const articles = await fetchHighOpportunityArticles(days);
        console.log(`[Trend Discovery] Found ${articles.length} high-opportunity articles`);

        if (articles.length < 5) {
            return {
                success: true,
                channel: 'trend-discovery',
                stats: {
                    articles_analyzed: articles.length,
                    duration_ms: Date.now() - startTime
                },
                message: 'Insufficient articles for trend analysis',
                trends: null
            };
        }

        // 2. 分析关键词频率
        console.log('[Trend Discovery] Analyzing keyword frequency...');
        const topKeywords = analyzeKeywordFrequency(articles);

        // 3. 识别热门类别
        console.log('[Trend Discovery] Identifying trending categories...');
        const trendingCategories = identifyTrendingCategories(articles);

        // 4. 生成AI趋势洞察
        console.log('[Trend Discovery] Generating AI trend insights with GLM-4 Plus...');
        const trendInsights = await generateTrendInsights(
            topKeywords,
            trendingCategories,
            articles.slice(0, 20)
        );

        // 5. 保存趋势数据
        const trendData = {
            date: new Date().toISOString().split('T')[0],
            keywords: topKeywords.map(k => ({ keyword: k.keyword, frequency: k.count })),
            categories: trendingCategories,
            insights: trendInsights
        };

        console.log('[Trend Discovery] Saving trends to FastAPI...');
        await saveTrendsToFastAPI(trendData);

        const duration = Date.now() - startTime;
        console.log(`[Trend Discovery] Completed in ${duration}ms`);

        return {
            success: true,
            channel: 'trend-discovery',
            execution_id: params.execution_id || `exec-${Date.now()}`,
            stats: {
                articles_analyzed: articles.length,
                keywords_found: topKeywords.length,
                categories_found: trendingCategories.length,
                duration_ms: duration
            },
            trends: trendInsights,
            message: `Discovered ${topKeywords.length} trending keywords and ${trendingCategories.length} categories`
        };

    } catch (error) {
        console.error('[Trend Discovery] Error:', error);
        return {
            success: false,
            channel: 'trend-discovery',
            error: error.message,
            duration_ms: Date.now() - startTime
        };
    }
}

// 导出
module.exports = {
    id: 'trend-discovery',
    name: 'AI Trend Discovery',
    version: '1.0.0',
    schedule: '0 */6 * * *',
    timeout: 600000, // 10分钟
    description: '分析高机会文章，发现新兴趋势并生成AI洞察',
    run: run
};

// 如果直接运行此脚本
if (require.main === module) {
    run({ days: 7 }).then(result => {
        console.log('Result:', JSON.stringify(result, null, 2));
        process.exit(result.success ? 0 : 1);
    }).catch(error => {
        console.error('Fatal error:', error);
        process.exit(1);
    });
}
