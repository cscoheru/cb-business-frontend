// Handle newline-delimited JSON response
const BRIGHT_DATA_API = 'https://api.brightdata.com/datasets/v3/scrape';
const BRIGHT_DATA_TOKEN = '1c7806b0-3f98-48da-93ce-8a745c40b062';

async function httpRequest(url, options) {
    const response = await fetch(url, options);
    if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    // Get text and parse newline-delimited JSON
    const text = await response.text();
    const lines = text.trim().split('\n').filter(line => line.trim());
    return lines.map(line => JSON.parse(line));
}

async function fetchAmazonByKeyword(keyword) {
    const payload = {
        input: [{
            keyword: keyword,
            url: 'https://www.amazon.com',
            pages_to_search: 1
        }]
    };

    const params = new URLSearchParams({
        dataset_id: 'gd_lwdb4vjm1ehb499uxs',
        notify: 'false',
        include_errors: 'true'
    });

    const url = `${BRIGHT_DATA_API}?${params}`;
    return await httpRequest(url, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${BRIGHT_DATA_TOKEN}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
    });
}

async function sendToBackend(products, categoryKey) {
    const backendUrl = 'http://103.59.103.85:8000/api/v1/batch/products';
    const payload = {
        products: products.map(p => ({
            asin: p.asin,
            title: p.name,
            price: p.final_price,
            rating: p.rating,
            reviews_count: p.num_ratings || 0,
            url: p.url,
            image: p.image,
            category: categoryKey,
            source: 'bright_data_amazon',
            fetched_at: new Date().toISOString()
        })),
        source: 'bright_data_amazon'
    };
    return await httpRequest(backendUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });
}

async function main() {
    console.log('🚀 Bright Data Search Test (NDJSON)');
    const startTime = Date.now();
    
    try {
        const products = await fetchAmazonByKeyword('wireless earbuds');
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        
        console.log(`✅ API response (${elapsed}s)`);
        console.log(`📊 Got ${products.length} products`);
        
        if (products.length > 0) {
            console.log('Sample product:', JSON.stringify(products[0]).substring(0, 200));
            
            console.log(`📤 Sending ${Math.min(5, products.length)} products to backend...`);
            const result = await sendToBackend(products.slice(0, 5), 'wireless_earbuds');
            console.log(`✅ Backend response:`, JSON.stringify(result, null, 2));
            
            return {
                success: true,
                products_sent: Math.min(5, products.length)
            };
        }
        
        return { success: false, message: 'No products' };
    } catch (error) {
        console.error(`❌ Error: ${error.message}`);
        return { success: false, error: error.message };
    }
}

main().then(result => {
    console.log('\n=== Final Result ===');
    console.log(JSON.stringify(result, null, 2));
    process.exit(result.success ? 0 : 1);
}).catch(err => {
    console.error('Failed:', err);
    process.exit(1);
});
