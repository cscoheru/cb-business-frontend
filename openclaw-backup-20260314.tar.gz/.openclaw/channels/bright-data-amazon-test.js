// bright-data-amazon-test.js
// Quick connectivity test using simple URL

const BRIGHT_DATA_API = 'https://api.brightdata.com/datasets/v3/scrape';
const BRIGHT_DATA_TOKEN = '1c7806b0-3f98-48da-93ce-8a745c40b062';

async function testBrightDataAPI() {
    // Simple product URL test (no discovery)
    const payload = {
        input: [{
            url: 'https://www.amazon.com/dp/B0CRMZHDG8',
            zipcode: '94107',
            language: ''
        }]
    };

    const params = new URLSearchParams({
        dataset_id: 'gd_l7q7dkf244hwjntr0',
        notify: 'false',
        include_errors: 'true'
    });

    const url = `${BRIGHT_DATA_API}?${params}`;

    console.log('🧪 Testing Bright Data API connectivity...');
    
    const startTime = Date.now();
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${BRIGHT_DATA_TOKEN}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        console.log(`Response time: ${elapsed}s`);

        if (!response.ok) {
            console.error(`HTTP ${response.status}: ${response.statusText}`);
            return { success: false, status: response.status };
        }

        const data = await response.json();
        console.log('✅ API is reachable and responding');
        
        // Check if we got any results
        const count = data.results?.[0]?.content?.length || 0;
        console.log(`Products returned: ${count}`);
        
        return {
            success: true,
            api_reachable: true,
            response_time: elapsed,
            products_count: count
        };

    } catch (error) {
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        console.error(`❌ Error after ${elapsed}s:`, error.message);
        return {
            success: false,
            error: error.message,
            response_time: elapsed
        };
    }
}

testBrightDataAPI().then(result => {
    console.log('\n=== Test Result ===');
    console.log(JSON.stringify(result, null, 2));
    process.exit(result.success || result.api_reachable ? 0 : 1);
}).catch(err => {
    console.error('Test crashed:', err);
    process.exit(1);
});
