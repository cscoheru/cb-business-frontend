/**
 * OpenClaw Channel: Oxylabs Product Monitor
 * 
 * 功能：监控12个产品类别的Amazon数据
 * 调度：每小时
 * 超时：10分钟
 * 
 * 数据流：
 * 1. 调用FastAPI获取各类别产品数据
 * 2. 批量写入cards.amazon_data
 * 3. 返回更新统计
 */

const http = require('http');
const https = require('https');

// 配置
const FASTAPI_BASE_URL = 'http://172.22.0.4:8000';
const PRODUCT_CATEGORIES = [
    'wireless_earbuds',
    'bluetooth_speakers',
    'smart_plugs',
    'desk_lamps',
    'phone_chargers',
    'fitness_trackers',
    'coffee_makers',
    'air_purifiers',
    'robot_vacuums',
    'instant_pots',
    'yoga_mats',
    'webcam'
];

/**
 * 发起HTTP请求
 */
function httpRequest(url, options = {}) {
    return new Promise((resolve, reject) => {
        const client = url.startsWith('https') ? https : http;
        const req = client.request(url, options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    resolve(JSON.parse(data));
                } catch (e) {
                    resolve(data);
                }
            });
        });
        
        req.on('error', reject);
        req.setTimeout(60000, () => {
            req.destroy();
            reject(new Error('Request timeout'));
        });
        
        if (options.body) {
            req.write(JSON.stringify(options.body));
        }
        req.end();
    });
}

/**
 * 获取指定类别的产品数据
 */
async function fetchCategoryProducts(category) {
    const url = `${FASTAPI_BASE_URL}/api/v1/cards/daily?category=${category}`;
    
    try {
        const response = await httpRequest(url, {
            method: 'GET',
            headers: {
                'Accept': 'application/json'
            }
        });
        
        // 从cards中提取产品数据
        if (response.cards && response.cards.length > 0) {
            return response.cards[0].amazon_data || null;
        }
        return null;
    } catch (error) {
        console.error(`Failed to fetch products for ${category}:`, error.message);
        return null;
    }
}

/**
 * 批量写入产品数据到FastAPI
 */
async function pushProductsToFastAPI(productsData) {
    const url = `${FASTAPI_BASE_URL}/api/v1/batch/products`;
    const payload = {
        products: productsData,
        source: 'openclaw-oxylabs',
        batch_id: `oxylabs-${Date.now()}`
    };

    try {
        const response = await httpRequest(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: payload
        });
        return response;
    } catch (error) {
        console.error('Failed to push products:', error.message);
        throw error;
    }
}

/**
 * 主执行函数
 */
async function run(params = {}) {
    console.log('[Oxylabs Monitor] Starting execution...');
    const startTime = Date.now();
    
    const categories = params.categories || PRODUCT_CATEGORIES;
    const limit = params.limit || categories.length;

    try {
        console.log(`[Oxylabs Monitor] Monitoring ${limit} categories...`);
        
        const results = [];
        let totalProducts = 0;

        // 并发获取所有类别数据
        const promises = categories.slice(0, limit).map(async (category) => {
            try {
                const productsData = await fetchCategoryProducts(category);
                if (productsData && productsData.products) {
                    totalProducts += productsData.products.length;
                    return {
                        category: category,
                        success: true,
                        product_count: productsData.products.length
                    };
                }
                return {
                    category: category,
                    success: false,
                    message: 'No products found'
                };
            } catch (error) {
                return {
                    category: category,
                    success: false,
                    error: error.message
                };
            }
        });

        const categoryResults = await Promise.all(promises);
        results.push(...categoryResults);

        const duration = Date.now() - startTime;
        const successCount = results.filter(r => r.success).length;

        console.log(`[Oxylabs Monitor] Completed: ${successCount}/${limit} categories, ${totalProducts} products`);

        return {
            success: true,
            channel: 'oxylabs-monitor',
            execution_id: params.execution_id || `exec-${Date.now()}`,
            stats: {
                total_categories: limit,
                successful: successCount,
                failed: limit - successCount,
                total_products: totalProducts,
                duration_ms: duration
            },
            results: results,
            message: `Monitored ${limit} categories, found ${totalProducts} products`
        };

    } catch (error) {
        console.error('[Oxylabs Monitor] Error:', error);
        return {
            success: false,
            channel: 'oxylabs-monitor',
            error: error.message,
            duration_ms: Date.now() - startTime
        };
    }
}

// 导出
module.exports = {
    id: 'oxylabs-monitor',
    name: 'Oxylabs Product Monitor',
    version: '1.0.0',
    schedule: '0 * * * *',
    timeout: 600000, // 10分钟
    description: '监控Amazon产品数据并更新到FastAPI',
    run: run
};

// 如果直接运行此脚本
if (require.main === module) {
    run({ limit: 3 }).then(result => {
        console.log('Result:', JSON.stringify(result, null, 2));
        process.exit(result.success ? 0 : 1);
    }).catch(error => {
        console.error('Fatal error:', error);
        process.exit(1);
    });
}
