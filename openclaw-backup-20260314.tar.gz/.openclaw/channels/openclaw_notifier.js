/**
 * OpenClaw通知模块
 * 
 * 功能: 在OpenClaw Channels中发送通知到FastAPI通知服务
 * 
 * 使用方法:
 *   const notifier = require('./openclaw_notifier.js');
 *   await notifier.success('RSS Crawler', '成功采集50篇文章');
 *   await notifier.error('RSS Crawler', '采集超时');
 */

const http = require('http');
const https = require('https');

// 配置
const NOTIFICATION_API_URL = 'http://172.22.0.4:8000/api/v1/notifications/notify';
const PUBLIC_NOTIFICATION_API = 'https://api.zenconsult.top/api/v1/notifications/notify';

/**
 * 发送通知到FastAPI通知服务
 */
async function sendNotification(title, message, priority = 'info', context = '') {
    const payload = {
        title: title,
        message: message,
        priority: priority,
        context: context
    };

    try {
        // 优先使用内网地址
        const url = NOTIFICATION_API_URL;
        const client = url.startsWith('https') ? https : http;

        return new Promise((resolve, reject) => {
            const req = client.request(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            }, (res) => {
                let data = '';
                res.on('data', chunk => data += chunk);
                res.on('end', () => {
                    try {
                        resolve(JSON.parse(data));
                    } catch (e) {
                        resolve(data);
                    }
                });
            });

            req.on('error', (error) => {
                console.error(`[Notifier] Failed to send notification: ${error.message}`);
                // 不抛出错误，避免中断Channel执行
                resolve({ success: false, error: error.message });
            });

            req.setTimeout(10000, () => {
                req.destroy();
                resolve({ success: false, error: 'timeout' });
            });

            req.write(JSON.stringify(payload));
            req.end();
        });
    } catch (error) {
        console.error(`[Notifier] Exception: ${error.message}`);
        return { success: false, error: error.message };
    }
}

/**
 * 成功通知
 */
async function success(channel, message) {
    return await sendNotification(
        `✅ ${channel} 执行成功`,
        message,
        'info'
    );
}

/**
 * 错误通知
 */
async function error(channel, message, errorDetail = '') {
    const fullMessage = errorDetail ? `${message}\n\n详情: ${errorDetail}` : message;
    return await sendNotification(
        `❌ ${channel} 执行失败`,
        fullMessage,
        'error',
        channel
    );
}

/**
 * 警告通知
 */
async function warning(channel, message) {
    return await sendNotification(
        `⚠️ ${channel} 警告`,
        message,
        'warning',
        channel
    );
}

/**
 * 开始执行通知
 */
async function started(channel, details = '') {
    return await sendNotification(
        `🔄 ${channel} 开始执行`,
        details || '开始执行...',
        'info',
        channel
    );
}

/**
 * 包装Channel执行 - 自动发送通知
 */
async function wrapChannelExecution(channelName, channelFunction, params = {}) {
    console.log(`[${channelName}] Starting execution...`);

    // 发送开始通知
    await started(channelName);

    try {
        // 执行Channel
        const result = await channelFunction(params);

        // 发送成功通知
        if (result && result.success) {
            await success(channelName, result.message || '执行完成');
        } else if (result && !result.success) {
            await error(channelName, result.error || '执行失败');
        }

        return result;
    } catch (error) {
        // 发送错误通知
        await error(channelName, error.message, error.stack);
        throw error;
    }
}

// 导出
module.exports = {
    sendNotification,
    success,
    error,
    warning,
    started,
    wrapChannelExecution
};

// 如果直接运行此脚本进行测试
if (require.main === module) {
    (async () => {
        console.log('Testing OpenClaw notification module...\n');

        console.log('1. Testing success notification...');
        await success('Test Channel', '这是测试消息');

        await new Promise(resolve => setTimeout(resolve, 1000));

        console.log('\n2. Testing error notification...');
        await error('Test Channel', '这是测试错误');

        await new Promise(resolve => setTimeout(resolve, 1000));

        console.log('\n3. Testing wrapped execution...');
        await wrapChannelExecution(
            'Test Wrapped Channel',
            async (params) => {
                console.log('Inside wrapped function');
                return { success: true, message: '测试成功' };
            }
        );

        console.log('\n✅ All tests completed!');
    })();
}
