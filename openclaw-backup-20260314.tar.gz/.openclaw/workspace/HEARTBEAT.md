# HEARTBEAT.md - CB-Business 监控任务

> 每30分钟自动执行，确保服务正常运行

## 任务清单

### 1. API 服务健康检查

```bash
curl -s http://localhost:8000/health
```

期望: {"status":"healthy"}

---

### 2. 产品 API 检查

```bash
curl -s "http://localhost:8000/api/v1/products/categories" | head -10
```

期望返回分类列表

---

### 3. 磁盘空间检查

```bash
df -h / | awk 'NR==2 {print $5}' | sed 's/%//'
```

警告条件: 使用率 > 80%

---

### 4. 内存检查

```bash
free -m | awk 'NR==2 {print $7}'
```

警告条件: 可用内存 < 500MB

---

## 正常状态

如果所有检查通过，返回: `HEARTBEAT_OK`

如果发现问题，记录问题详情。
