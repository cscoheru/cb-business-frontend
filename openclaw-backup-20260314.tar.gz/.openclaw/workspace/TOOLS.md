# TOOLS.md - CB-Business 工具配置

## 服务端点

### 后端 API
- 生产 API: https://api.zenconsult.top
- 本地 API: http://localhost:8000
- Health Check: http://localhost:8000/health

### 数据库
- PostgreSQL: 139.224.42.111:5432
  - Database: crawler_db
  - User: cbuser
- Redis: 139.224.42.111:6379

### Oxylabs API
- Base URL: https://realtime.oxylabs.io/v1/queries
- Username: fisher_VEpfJ
- Password: z7UnsI2Hkug_

## 文件路径

### 项目目录
- 后端: /root/cb-business
- 日志: /root/cb-business/logs/
- 备份: /root/cb-business/backups/

### Docker 服务
- API 容器: cb-business-api
- PostgreSQL: cb-business-postgres
- Redis: cb-business-redis

## 常用命令

### 服务管理
docker-compose -f /root/cb-business/docker-compose.prod.yml ps
docker-compose -f /root/cb-business/docker-compose.prod.yml logs --tail=50 api

### 数据库查询
docker exec -it cb-business-postgres psql -U cbuser -d crawler_db -c "SELECT COUNT(*) FROM articles;"

### API 测试
curl -s http://localhost:8000/api/v1/crawler/stats | jq
curl -s http://localhost:8000/api/v1/products/trending?category=electronics&limit=2 | jq

## 爬虫配置

### RSS 源 (45个)
- 配置文件: /root/cb-business/config/sources_config.json

### 爬虫状态
- 文章总数: 286+
- 已处理: 128篇
- 爬取间隔: APScheduler 每2小时
